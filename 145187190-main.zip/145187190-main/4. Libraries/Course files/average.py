import statistics

print(statistics.mean([100,90]))