x = int(input("what's x? "))
y = int(input("what's y? "))

if x!=y:
    print("x is not equal to y")
else:
    print("x is equal to y")