m = int(input("Number of kg: "))
E = m*(pow(300000000,2))
print(E)