slower = input ()
slower = slower.replace(" ", "...")
print(slower)