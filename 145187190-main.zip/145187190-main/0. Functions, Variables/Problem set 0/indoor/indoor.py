yell = input("The following text will be converted to a non-yell \n")
yell = yell.lower()
print (yell)