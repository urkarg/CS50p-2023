students = ["Hermione", "Harry", "Ron"]

for i, student in enumerate(students):
    print(i+1, students[i])
