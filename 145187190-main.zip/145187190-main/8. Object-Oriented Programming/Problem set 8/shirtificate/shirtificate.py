from fpdf import FPDF

class PDF(FPDF):
    def footer(self):
        self.set_font("helvetica", "B", 45)
        self.set_text_color(r=0)
        self.text(48, 45,"CS50 Shirtificate")
        self.ln(10)

    def shirt_text(self, name):
        self.set_font("helvetica", "B", 30)
        self.set_text_color(r=255)
        self.text(65, 150, f"{name} took CS50")

    def draw_line(self, x1, y1, x2, y2):
        self.set_line_width(1)
        self.set_draw_color(r=0)
        self.line(x1, y1, x2, y2)

    def draw_circle(self, x, y, r):
        self.set_line_width(1.5)
        self.set_draw_color(0)
        self.set_fill_color(0, 255, 0)
        self.circle(x, y, r, style="FD")


def main():
    pdf = PDF()
    pdf.add_page()
    pdf.image("shirtificate.png", y=75, w=190, keep_aspect_ratio = True)
    pdf.shirt_text(input("Name: "))
    pdf.draw_line(60, 135, 60, 155)
    pdf.draw_line(60, 135, 160, 135)
    pdf.draw_line(160, 135, 160, 155)
    pdf.draw_line(60, 155, 160, 155)
    pdf.draw_circle(90, 100, 35)
    pdf.output("shirtificate.pdf")


if __name__ == "__main__":
    main()