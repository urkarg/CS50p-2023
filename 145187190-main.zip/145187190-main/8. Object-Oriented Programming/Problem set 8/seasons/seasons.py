from datetime import date, datetime
import sys
import inflect


class Bd_conv:
    def __init__(self, birth_date):
        self.birth_date = birth_date

    def __str__(self):
        return f"{self.birth_date}"

    @classmethod
    def get(cls):
        birth_date = input("Date of Birth: ")
        return cls(birth_date)

    @property
    def birth_date(self):
        return self._birth_date

    @birth_date.setter
    def birth_date(self, birth_date):
        try:
            self._birth_date = datetime.strptime(birth_date, "%Y-%m-%d").date()
        except:
            sys.exit("Invalid date")

    def daelta_min (self):
        return (date.today()-self.birth_date).days * 1440



def main():
    p = inflect.engine()
    bd = Bd_conv.get()
    seasons = p.number_to_words(bd.daelta_min(), andword="")
    print(f"{seasons.capitalize()} minutes")


if __name__ == "__main__":
    main()