from seasons import Bd_conv

def test_valid_date ():
    assert Bd_conv("1992-04-30")